const Product = require("../model/product");
var Users=require("../model/product");
var products = [
    { productId: 301, productName: "Apple", price: 400 },
    { productId: 302, productName: "Orange", price: 320 },
    { productId: 303, productName: "Banana", price: 140 },
    { productId: 304, productName: "Guvava", price: 120 },
    { productId: 305, productName: "Cherry", price: 130 },
    { productId: 306, productName: "Graps", price: 80 },
    { productId: 307, productName: "Berry", price: 170 }
]

function Get() {
    return products
}
function Check(productId) {
    var pos=products.findIndex(product =>product.productId == productId);
    if(pos >=0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
function Add(productId,productName,price) {
    products.push(new Product(productId,productName,price))
    return true
}
function Update(productId,productName,price) {
    if (Check(productId)) {
        var pos = products.findIndex(item => item.productId == request.body.productId)
        products[pos] = new  Product(productId,productName,price)
        return true
    } else {
        return false
    }
}
function DeleteProduct(productId) {
    if (Check(productId)) {
        var pos = products.findIndex(item => item.productId == productId)
        products.splice(pos, 1)
    } else {
        return false
    }
}

module.exports={Get,Add,Update,DeleteProduct}