var express=require("express");
const morgan=require("morgan");//module to be installed
const path=require("path");
// logging of the requests -- morgan
const fs=require("fs");
const productController = require("../controllers/productControllers")



var router=express.Router();

// middleware specific to products route
router.use((request,response,next)=>{
    console.log("Products routes middleware",request.rootDirName);// path to he root folder
    var wStream=fs.createWriteStream(path.join(request.rootDirName,"log","serverLog.txt"),{flags:"a"});
    morgan("short",{stream:wStream})
    wStream.close();
    next();
})

//get request to /products
router.get("/",(request,response)=>{
    var res=productController.Get();
    if(res.length>0)
    {
        response.send(res);
    } else {
        response.status(403).send({msg:"No Products there"})
    }
})

router.post("/add",(request,response)=>{
    productController.Add(request.body.productId, request.body.productName, request.body.price)
    response.send(productController.Get())
})

router.put("/update",(request,response)=>{
    var res = productController.Update(request.body.productId, request.body.productName, request.body.price) 
    if (res) {
        response.send(productController.Get())
    } else {
        response.status(403).send({msg:"Product couldn't be updated"})
    }
})

router.delete("/delete",(request,response)=>{
    var res = productController.DeleteProduct(request.body.productId)
    if (res) {
        response.send(productController.Get())
    } else {
        response.status(403).send({msg:"Product could not be deleted"})
    }
})

module.exports=router;

module.exports=router;



