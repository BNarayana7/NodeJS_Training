const { MongoClient } = require("mongodb");
const uri = "mongodb://127.0.0.1:27017/";
const mongoClient = new MongoClient(uri, { useUnifiedTopology: true });
async function run() {

    try {
        var client = await mongoClient.connect()

        var dbName = client.db("dxcDb");
        var collName = dbName.collection("employees");
        // const deleteItem = {empId:105}
        // collName.deleteOne(deleteItem)
        // .then((res)=>{
        //     console.log("Deleted Successfully ",res);
        // })
        // .catch((err)=>{
        //     console.log("Error during updation ",err);
        //     mongoClient.close();
        // })
        const deleteItem = {salary:{$gt:60000}}
        collName.deleteMany(deleteItem)
        .then((res)=>{
            console.log("Deleted Successfully ",res);
        })
        .catch((err)=>{
            console.log("Error during updation ",err);
            mongoClient.close();
        })       
    }
    catch (err) {
        
        console.log("Error", err)
    } 
}
run();