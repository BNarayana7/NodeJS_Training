const fs = require('fs');
const path = require('path');

fs.copyFile('text1.txt', 'text2.txt', (err) => {
    console.log('Assigmnet 2')
    if (err) {
        console.log("text1 content not copyed")
    } else {
        console.log('Successfully copyed text1 content into text2');
    }
});

const cloneDir = ()=>{
    console.log('Assigmnet 2')
    var folderDir = "./cloneDir"
    fs.mkdir(path.join(folderDir), (err) => {
        if (err) {
            console.log("Directory Not Created" + err);
        } else {
            console.log("Directory created successfully");            
            fs.cp(folderDir, folderDir, { recursive: true }, (err) => {
                if (err) {
                    console.log("Directory Not cloned",err);
                } else {
                    console.log("Directory cloned successfully");
                    return folderDir;
                }
            });
        }
    })
}
cloneDir()


const FileExist = ()=> {
    console.log('Assignment 3')
    var filePath = './text1.txt'
    fs.stat(filePath, (err, data) => {
        if (err) {
            console.log('File does not exsit');
        } else {
            console.log('File exsit');
            return data.isFile();
        }
    });
}
FileExist()