const express=require("express");
const path=require("path");
const bodyParser=require("body-parser");

const morgan=require("morgan");

const fs=require("fs");

const port=3000;
var productArr = [{ productId: 101, productName: "Car", price: 500000, quantity: "2", category: "sports" },
{ productId: 102, productName: "Truck", price: 2000000, quantity: "1", category: "transport" },
{ productId: 103, productName: "Mobile", price: 40000, quantity: "5", category: "electronics" },
{ productId: 104, productName: "Bike", price: 80000, quantity: "4", category: "electric" },
{ productId: 105, productName: "Television", price: 35000, quantity: "8", category: "electronics" }]
var wStream=fs.createWriteStream(path.join(__dirname,"log","serverLog.txt"),{flags:"a"});


var app=express();
app.use(morgan("combined",{stream:wStream}));

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

app.get("/product",(request,response)=>{
    response.send(productArr);
  })

app.post("/product",(request,response)=>{
    productArr.push(request.body);
    response.end("Product Details added successfully")
  })

  app.put("/product",(request,response)=>{
    var pos = productArr.findIndex(item => item.productId == request.body.productId)
    // productArr.splice(pos, 0, productArr.price)
    productArr[pos] = request.body;
    var res = response.json(productArr)
})

app.delete("/product",(request,response)=>{
    var pos = productArr.findIndex(item => item.productId == request.body.productId)
    productArr.splice(pos, 1)
    var res = response.json(productArr)
})


console.log("Express example");
app.listen(port,()=>{
    console.log(`Server started at port : ${port}`);
})