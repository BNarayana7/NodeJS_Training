console.log('Squares of all the elements without using the map method')
var arr=[10,20,30,40,50];
var Squares = () => {
    let squaresArr = []
    for(let i=0;i<arr.length;i++){
        squaresArr.push(arr[i]*arr[i])
    }
    console.log('Squares of Array is : ',squaresArr)
}
// Squares()

module.exports = Squares