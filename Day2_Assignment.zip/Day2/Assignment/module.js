var Squares = require('./assign1')
var maskedPhoneNum = require('./assign2')
var getHighSalEmp = require('./assign3')

Squares()
maskedPhoneNum('1234567890')
getHighSalEmp()