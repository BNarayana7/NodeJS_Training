console.log('Mask on string')

const maskedPhoneNum = (phoneNum)=>{
var phNum = phoneNum.slice(0, 3) + phoneNum.slice(3, phoneNum.length -3).replace(/\d/g,'*') + phoneNum.slice(phoneNum.length -3);
console.log("maskedPhoneNumebr : "+phNum);
}
// maskedPhoneNum('1234567890')

module.exports = maskedPhoneNum