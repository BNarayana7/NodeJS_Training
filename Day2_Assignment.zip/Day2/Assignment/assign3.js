console.log('In obj which has the highest salary')

var empArr=[
    {empId:101,empName:"Asha",salary:1001,deptId:"D1"},
{empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
{empId:103,empName:"Karan",salary:2000,deptId:"D2"},
{empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
{empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
{empId:106,empName:"Pran",salary:4000,deptId:"D3"},
{empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]
 
const getHighSalEmp = () =>{
    var highSalEmp;
    for(let i=0;i<empArr.length;i++){
      if(!highSalEmp || empArr[i].salary > highSalEmp.salary){
        highSalEmp = empArr[i];
      }
    }
    console.log('Highest salary is: ',highSalEmp);
 }

const getHighSalEmp1 = () =>{
   var highSalEmp;
   for(var key in empArr){
     if(!highSalEmp || empArr[key].salary > highSalEmp.salary){
       highSalEmp = empArr[key];
     }
   }
   console.log('Highest salary is: ',highSalEmp);
}

// getHighSalEmp()
// getHighSalEmp1()

module.exports = getHighSalEmp