const fs=require("fs");
fs.readFile("file2.txt",function(err,data){
    console.log("File 2 read operation complete");
    if(err)
    {
        console.log("Error reading file 2",err);
    }
    else
    {
        console.log("Successfully read the file 2with the data");
    }
})
fs.readFile("file1.txt",function(err,data){
    console.log("File read operation complete of file1");
    if(err)
    {
        console.log("Error reading file 1",err);
    }
    else
    {
        console.log("Successfully read the file 1 with the data");
    }
})

