console.log('Assignment 1')
var fs = require('fs')
var addContent = ''
fs.readFile("file1.txt",(err, cont)=>{
    if(cont){
        console.log('content from :',cont.toString())
        addContent += cont
        fs.writeFile("assign1_file4.txt",addContent,{flag:'a'},(err)=>{
            if(err){
                console.log("File1 Not successfully added in file4")
            } else {
                console.log("File1 successfully added in file4")
            }
        })
    } else {
        console.log("Error1 : ",err)
    }
})

fs.readFile("file2.txt",(err, cont)=>{
    if(cont){
        console.log('content from :',cont.toString())
        addContent += "\n",cont
        fs.writeFile("assign1_file4.txt",addContent,{flag:'a'},(err)=>{
            if(err){
                console.log("File2 Not successfully added in file4")
            } else {
                console.log("File2 successfully added in file4")
            }
        })
    } else {
        console.log("Error1 : ",err)
    }
})

fs.readFile("file3.txt",(err, cont)=>{
    if(cont){
        console.log('content from :',cont.toString())
        addContent += "\n"+cont
        fs.writeFile("assign1_file4.txt",addContent,{flag:'a'},(err)=>{
            if(err){
                console.log("File3 Not successfully added in file4")
            } else {
                console.log("File3 successfully added in file4")
            }
        })
    } else {
        console.log("Error3 : ",err)
    }
})