//var obj=require("./module1");//custom module -- relative path to that module
const fs=require("fs");// in built module -- fs -- name of the module; core module; shipped along with nodejs -- no need to install explicitly
// execute the in built core fs module
// 2 params ; name of the file to be read in the string; callback function
fs.readFile("file1.txt",function(err,data){
    console.log("File read operation complete");
    console.log("Err",err);
    if(err)
    {
        console.log("Error reading file",err);
    }
    else
    {
        console.log("Successfully read the file with the data",data.toString());
    }
})
