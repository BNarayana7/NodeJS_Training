console.log("Read from 3 files and add all the contents of 3 files into file4")
var fs = require('fs')
let file1 = '', file2 = '', file3 = ''
fs.readFile('file1.txt',(err,content)=>{
    if(!!content){
        console.log('Content from : ',content.toString())
        file1 = "File1.... "+content
        fs.readFile('file2.txt',(err,content)=>{
            if(!!content){
                console.log('Content from : ',content.toString())
                file2 = file1+"\nFile2.... "+content
                fs.readFile('file3.txt',(err,content)=>{
                    if(!!content){
                        console.log('Content from : ',content.toString())
                        file3 = file2+"\nFile3.... "+content
                        fs.writeFile('file4.txt',file3,(err)=>{
                            if(err){
                                console.log("Error3 : ",err)
                            } else {
                                console.log("Three files content successfully added in file4")
                            }
                        })
                    } else {
                        {
                            console.log('Error : ',err)
                        }
                    }
                })
            } else {
                {
                    console.log('Error : ',err)
                }
            }
        })
    } else {
        {
            console.log('Error : ',err)
        }
    }
})



