exports.f1 = (empArr, salary)=>{
    var obj = ''
    var findSalaryIndex = empArr.findIndex(sal => sal.salary == salary)
    console.log('findSalaryIndex',findSalaryIndex)
    for (var i = 0; i < empArr.length; i++) {
        if (empArr[i].salary == salary) {
            obj = i;
        }
    }
    console.log('obj',obj)
}

exports.addObj = (empArr, addIndex, index)=>{
    var newObj = {empId:144,empName:"Nani",salary:10000,deptId:"A1"}
    empArr.splice(addIndex, index, newObj)
    console.log('addNewObj : ',empArr)
}

exports.removeObj = (empArr, removeIndex)=>{
    empArr.splice(removeIndex, 1)
    console.log('removeObj : ',empArr)
}

exports.empDetails = (empArr, empId)=>{
    var paricularEmpDetails = empArr.filter(item => item.empId == empId)
    console.log('paricularEmpDetails',paricularEmpDetails)
}