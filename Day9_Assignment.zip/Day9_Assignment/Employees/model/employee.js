class Employee
{
    empId;
    empName;
    salary;
    deptId;

    constructor(empId,empName,salary,deptId)
    {
        this.empId=empId;
        this.empName=empName;
        this.salary=salary; 
        this.deptId=deptId 
    }
}
module.exports=Employee;