var express=require("express");
const morgan=require("morgan");//module to be installed
const path=require("path");
// logging of the requests -- morgan
const fs=require("fs");
const employeeController = require("../controllers/employeeControllers")



var router=express.Router();

// middleware specific to products route
router.use((request,response,next)=>{
    var wStream=fs.createWriteStream(path.join(request.rootDirName,"log","serverLog.txt"),{flags:"a"});
    morgan("short",{stream:wStream})
    wStream.close();
    next();
})


router.get("/",(request,response)=>{
    var res=employeeController.Get();
    if(res.length>0)
    {
        response.send(res);
    } else {
        response.status(403).send({msg:"No Employee Details There"})
    }
})

router.post("/add",(request,response)=>{
    const res = employeeController.Add(request.body.empId, request.body.empName, request.body.salary,request.body.deptId)
    if(res){
        response.send({msg:"Employee Details Added Successfully",data:employeeController.Get()})
    } else {
        response.send({msg:"Employee Details Not Added",error:res})
    }
})

router.put("/update",(request,response)=>{
    var res = employeeController.Update(request.body.empId, request.body.empName, request.body.salary) 
    if (res) {
        response.send({msg:"Employee Details Updated Successfully",data:employeeController.Get()})
    } else {
        response.status(403).send({msg:"Employee Details Not Updated",data:employeeController.Get()})
    }
})

router.delete("/delete",(request,response)=>{
    var res = employeeController.DeleteEmployee(request.body.empId)
    if (res) {
        response.send({msg:"Employee Details Deleted Successfully",data:employeeController.Get()})
    } else {
        response.status(403).send({msg:"Employee Details Not Deleted",data:employeeController.Get()})
    }
})

module.exports=router;

module.exports=router;



